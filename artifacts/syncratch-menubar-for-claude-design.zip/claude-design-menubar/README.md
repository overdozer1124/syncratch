# Claude Design 用 — Syncratch メニューバー素材

現在のメニューバー（ツールバー）の構造・文言・スタイルを再現／リデザインするための最小セットです。

## 含まれるファイル

- `apps/editor-web/index.html` — メニュー構造とラベル（設定 / ファイル / 編集 / いっしょに作る / Google ドライブ / AI など）
- `apps/editor-web/src/style.css` — ツールバー・パネルの見た目
- `apps/editor-web/public/branding/menu/*.svg` — 設定・ファイル・編集アイコン
- `apps/editor-web/public/branding/google-drive-2026-color-64dp.png` — 右側ステータス用 Drive アイコン

## 使い方

この zip を Claude Design にアップロードし、メニューバーをよりわかりやすくリデザインするよう依頼してください。
